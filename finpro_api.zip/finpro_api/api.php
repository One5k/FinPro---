<?php
header("Content-Type: application/json; charset=UTF-8");

// الاتصال بقاعدة البيانات
require 'config.php'; // تأكد من أن هذا الملف يقوم بإنشاء الاتصال بقاعدة البيانات بشكل صحيح

// تحديد نقطة النهاية (endpoint) بناءً على المعاملات في الـ URL
$method = $_SERVER['REQUEST_METHOD'];
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : null;

if (!$endpoint) {
    echo json_encode(["message" => "No endpoint specified"]);
    exit();
}

switch ($endpoint) {
    case 'clients':
        handleClients($method, $conn);
        break;
    case 'transactions':
        handleTransactions($method, $conn);
        break;
    case 'clients_with_totals':
        handleClientsWithTotals($method, $conn);
        break;
    default:
        echo json_encode(["message" => "Invalid endpoint"]);
        break;
}

$conn->close();

// دوال التعامل مع العملاء
function handleClients($method, $conn) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                getClient($_GET['id'], $conn);
            } else {
                getClients($conn);
            }
            break;
        case 'POST':
            addClient($conn);
            break;
        case 'PUT':
            if (isset($_GET['id'])) {
                updateClient($_GET['id'], $conn);
            } else {
                echo json_encode(["message" => "Client ID is required for updating"]);
            }
            break;
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteClient($_GET['id'], $conn);
            } else {
                echo json_encode(["message" => "Client ID is required for deleting"]);
            }
            break;
        default:
            echo json_encode(["message" => "Invalid request method for clients"]);
            break;
    }
}

// دوال التعامل مع المعاملات
function handleTransactions($method, $conn) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['client_id'])) {
                getTransactions($_GET['client_id'], $conn);
            } elseif (isset($_GET['id'])) {
                getTransaction($_GET['id'], $conn);
            } else {
                echo json_encode(["message" => "Client ID or Transaction ID is required"]);
            }
            break;
        case 'POST':
            addTransaction($conn);
            break;
        case 'PUT':
            if (isset($_GET['id'])) {
                updateTransaction($_GET['id'], $conn);
            } else {
                echo json_encode(["message" => "Transaction ID is required for updating"]);
            }
            break;
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteTransaction($_GET['id'], $conn);
            } else {
                echo json_encode(["message" => "Transaction ID is required for deleting"]);
            }
            break;
        default:
            echo json_encode(["message" => "Invalid request method for transactions"]);
            break;
    }
}

// دوال التعامل مع الإجماليات
function handleClientsWithTotals($method, $conn) {
    if ($method == 'GET') {
        getClientsWithTotals($conn);
    } else {
        echo json_encode(["message" => "Invalid request method for clients_with_totals"]);
    }
}

// دوال العملاء
function getClients($conn) {
    $sql = "SELECT * FROM clients";
    $result = $conn->query($sql);
    $clients = [];

    while ($row = $result->fetch_assoc()) {
        $clients[] = $row;
    }

    echo json_encode($clients);
}

function getClient($id, $conn) {
    $id = intval($id);
    $sql = "SELECT * FROM clients WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        echo json_encode($row);
    } else {
        echo json_encode(["message" => "Client not found"]);
    }
}

function addClient($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['name']) || !isset($data['phone']) || !isset($data['address'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    $name = $conn->real_escape_string($data['name']);
    $phone = $conn->real_escape_string($data['phone']);
    $address = $conn->real_escape_string($data['address']);

    $sql = "INSERT INTO clients (name, phone, address) VALUES ('$name', '$phone', '$address')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Client added successfully", "id" => $conn->insert_id]);
    } else {
        echo json_encode(["message" => "Error adding client: " . $conn->error]);
    }
}

function updateClient($id, $conn) {
    $id = intval($id);
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['name']) || !isset($data['phone']) || !isset($data['address'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    $name = $conn->real_escape_string($data['name']);
    $phone = $conn->real_escape_string($data['phone']);
    $address = $conn->real_escape_string($data['address']);

    $sql = "UPDATE clients SET name='$name', phone='$phone', address='$address' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Client updated successfully"]);
    } else {
        echo json_encode(["message" => "Error updating client: " . $conn->error]);
    }
}

function deleteClient($id, $conn) {
    $id = intval($id);
    $sql = "DELETE FROM clients WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["message" => "Client deleted successfully"]);
    } else {
        echo json_encode(["message" => "Error deleting client: " . $conn->error]);
    }
}

// دوال المعاملات
function getTransactions($client_id, $conn) {
    $client_id = intval($client_id);
    $sql = "SELECT * FROM transactions WHERE client_id = $client_id ORDER BY date DESC";
    $result = $conn->query($sql);
    $transactions = [];

    while ($row = $result->fetch_assoc()) {
        // إضافة مسار الصورة إلى بيانات المعاملة
        $transactions[] = [
            "id" => $row['id'],
            "client_id" => $row['client_id'],
            "amount" => $row['amount'],
            "details" => $row['details'],
            "date" => $row['date'],
            "type" => $row['type'],
            "image_path" => $row['image_path'] // مسار الصورة
        ];
    }

    echo json_encode($transactions);
}

function getTransaction($id, $conn) {
    $id = intval($id);
    $sql = "SELECT * FROM transactions WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            "id" => $row['id'],
            "client_id" => $row['client_id'],
            "amount" => $row['amount'],
            "details" => $row['details'],
            "date" => $row['date'],
            "type" => $row['type'],
            "image_path" => $row['image_path']
        ]);
    } else {
        echo json_encode(["message" => "Transaction not found"]);
    }
}

function addTransaction($conn) {
    // التعامل مع الطلبات من نوع JSON
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['client_id']) || !isset($data['amount']) || !isset($data['details']) || !isset($data['date']) || !isset($data['type'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    $client_id = intval($data['client_id']);
    $amount = floatval($data['amount']);
    $details = $conn->real_escape_string($data['details']);
    $date = $conn->real_escape_string($data['date']);
    $type = $conn->real_escape_string($data['type']);

    // التعامل مع الصورة المشفرة بـ Base64 إذا كانت موجودة
    $image_path = NULL;
    if (isset($data['image_base64']) && !empty($data['image_base64'])) {
        $image_data = $data['image_base64'];
        // استخراج نوع الصورة وبياناتها
        if (preg_match('/data:image\/(\w+);base64,/', $image_data, $type_match)) {
            $image_data = substr($image_data, strpos($image_data, ',') + 1);
            $image_type = strtolower($type_match[1]); // jpg, png, gif

            if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo json_encode(["message" => "Invalid image format"]);
                return;
            }

            $image_data = base64_decode($image_data);
            if ($image_data === false) {
                echo json_encode(["message" => "Base64 decode failed"]);
                return;
            }
        } else {
            echo json_encode(["message" => "Invalid image data"]);
            return;
        }

        // إنشاء مجلد uploads إذا لم يكن موجودًا
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        // إنشاء اسم ملف فريد
        $file_name = uniqid() . "." . $image_type;
        $file_path = $target_dir . $file_name;

        // حفظ الصورة على الخادم
        if (file_put_contents($file_path, $image_data)) {
            $image_path = $file_path;
        } else {
            echo json_encode(["message" => "Error saving image"]);
            return;
        }
    }

    // إدخال المعاملة في قاعدة البيانات
    $sql = "INSERT INTO transactions (client_id, amount, details, date, type, image_path) VALUES ($client_id, $amount, '$details', '$date', '$type', '$image_path')";

    if ($conn->query($sql) === TRUE) {
        // تحديث رصيد العميل
        if ($type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance + $amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance - $amount WHERE id = $client_id";
        }
        $conn->query($balance_update);

        echo json_encode(["message" => "Transaction added successfully", "id" => $conn->insert_id]);
    } else {
        echo json_encode(["message" => "Error adding transaction: " . $conn->error]);
    }
}

function updateTransaction($id, $conn) {
    // التعامل مع الطلبات من نوع JSON
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['amount']) || !isset($data['details']) || !isset($data['date']) || !isset($data['type'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    $id = intval($id);
    $new_amount = floatval($data['amount']);
    $details = $conn->real_escape_string($data['details']);
    $date = $conn->real_escape_string($data['date']);
    $new_type = $conn->real_escape_string($data['type']);

    // الحصول على المعاملة الحالية لمعرفة نوعها القديم
    $sql = "SELECT * FROM transactions WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        $old_type = $row['type'];
        $old_amount = floatval($row['amount']);
        $client_id = $row['client_id'];

        // إلغاء تأثير المعاملة القديمة على رصيد العميل
        if ($old_type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance - $old_amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance + $old_amount WHERE id = $client_id";
        }
        $conn->query($balance_update);

        // التعامل مع الصورة المشفرة بـ Base64 إذا كانت موجودة
        $image_path = $row['image_path']; // الحفاظ على الصورة القديمة إذا لم يتم تحديثها
        if (isset($data['image_base64']) && !empty($data['image_base64'])) {
            $image_data = $data['image_base64'];
            // استخراج نوع الصورة وبياناتها
            if (preg_match('/data:image\/(\w+);base64,/', $image_data, $type_match)) {
                $image_data = substr($image_data, strpos($image_data, ',') + 1);
                $image_type = strtolower($type_match[1]); // jpg, png, gif

                if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                    echo json_encode(["message" => "Invalid image format"]);
                    return;
                }

                $image_data = base64_decode($image_data);
                if ($image_data === false) {
                    echo json_encode(["message" => "Base64 decode failed"]);
                    return;
                }
            } else {
                echo json_encode(["message" => "Invalid image data"]);
                return;
            }

            // إنشاء مجلد uploads إذا لم يكن موجودًا
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true);
            }

            // إنشاء اسم ملف فريد
            $file_name = uniqid() . "." . $image_type;
            $file_path = $target_dir . $file_name;

            // حفظ الصورة على الخادم
            if (file_put_contents($file_path, $image_data)) {
                $image_path = $file_path;

                // حذف الصورة القديمة إذا كانت موجودة
                if ($row['image_path'] && file_exists($row['image_path'])) {
                    unlink($row['image_path']);
                }
            } else {
                echo json_encode(["message" => "Error saving image"]);
                return;
            }
        }

        // تحديث المعاملة في قاعدة البيانات
        $sql_update = "UPDATE transactions SET amount = $new_amount, details = '$details', date = '$date', type = '$new_type', image_path = '$image_path' WHERE id = $id";

        if ($conn->query($sql_update) === TRUE) {
            // تطبيق تأثير المعاملة الجديدة على رصيد العميل
            if ($new_type == 'مدين') {
                $balance_update_new = "UPDATE clients SET balance = balance + $new_amount WHERE id = $client_id";
            } else {
                $balance_update_new = "UPDATE clients SET balance = balance - $new_amount WHERE id = $client_id";
            }
            $conn->query($balance_update_new);

            echo json_encode(["message" => "Transaction updated successfully"]);
        } else {
            echo json_encode(["message" => "Error updating transaction: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Transaction not found"]);
        return;
    }
}

function deleteTransaction($id, $conn) {
    $id = intval($id);

    // الحصول على المعاملة الحالية لمعرفة نوعها ومبلغها
    $sql = "SELECT * FROM transactions WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        $type = $row['type'];
        $amount = floatval($row['amount']);
        $client_id = $row['client_id'];

        // تحديث رصيد العميل بناءً على نوع المعاملة
        if ($type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance - $amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance + $amount WHERE id = $client_id";
        }
        $conn->query($balance_update);

        // حذف الصورة إذا كانت موجودة
        if ($row['image_path'] && file_exists($row['image_path'])) {
            unlink($row['image_path']);
        }

        // حذف المعاملة
        $sql = "DELETE FROM transactions WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "Transaction deleted successfully"]);
        } else {
            echo json_encode(["message" => "Error deleting transaction: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Transaction not found"]);
    }
}

// دوال الإجماليات
function getClientsWithTotals($conn) {
    $sql_given = "SELECT SUM(amount) as total_given FROM transactions WHERE type = 'مدين'";
    $sql_taken = "SELECT SUM(amount) as total_taken FROM transactions WHERE type = 'دائن'";

    $result_given = $conn->query($sql_given);
    $result_taken = $conn->query($sql_taken);

    $total_given = 0;
    $total_taken = 0;

    if ($row = $result_given->fetch_assoc()) {
        $total_given = floatval($row['total_given']);
    }

    if ($row = $result_taken->fetch_assoc()) {
        $total_taken = floatval($row['total_taken']);
    }

    echo json_encode([
        "total_given" => $total_given,
        "total_taken" => $total_taken
    ]);
}
?>
