<?php
// تعيين نوع المحتوى إلى JSON وترميز الأحرف إلى UTF-8
header("Content-Type: application/json; charset=UTF-8");

// الاتصال بقاعدة البيانات
require 'config.php'; // تأكد من أن هذا الملف يقوم بإنشاء الاتصال بقاعدة البيانات بشكل صحيح

// تحديد طريقة الطلب (GET, POST, PUT, DELETE)
$method = $_SERVER['REQUEST_METHOD'];

// تحديد نقطة النهاية (endpoint) بناءً على المعاملات في الـ URL
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : null;

// التحقق من وجود نقطة النهاية، إذا لم تكن موجودة، إرجاع رسالة خطأ
if (!$endpoint) {
    echo json_encode(["message" => "No endpoint specified"]);
    exit();
}

// توجيه الطلب إلى الدالة المناسبة بناءً على نقطة النهاية المحددة
switch ($endpoint) {
    case 'clients':
        handleClients($method, $conn);
        break;
    case 'transactions':
        handleTransactions($method, $conn);
        break;
    case 'clients_with_totals':
        handleClientsWithTotals($method, $conn);
        break;
    default:
        echo json_encode(["message" => "Invalid endpoint"]);
        break;
}

// إغلاق الاتصال بقاعدة البيانات بعد الانتهاء من المعالجة
$conn->close();

/**
 * دالة التعامل مع طلبات العملاء
 *
 * @param string $method طريقة الطلب (GET, POST, PUT, DELETE)
 * @param object $conn اتصال قاعدة البيانات
 */
function handleClients($method, $conn) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                getClient($_GET['id'], $conn); // جلب عميل محدد بناءً على المعرف
            } else {
                getClients($conn); // جلب جميع العملاء
            }
            break;
        case 'POST':
            addClient($conn); // إضافة عميل جديد
            break;
        case 'PUT':
            if (isset($_GET['id'])) {
                updateClient($_GET['id'], $conn); // تحديث بيانات عميل محدد
            } else {
                echo json_encode(["message" => "Client ID is required for updating"]);
            }
            break;
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteClient($_GET['id'], $conn); // حذف عميل محدد
            } else {
                echo json_encode(["message" => "Client ID is required for deleting"]);
            }
            break;
        default:
            echo json_encode(["message" => "Invalid request method for clients"]);
            break;
    }
}

/**
 * دالة التعامل مع طلبات المعاملات
 *
 * @param string $method طريقة الطلب (GET, POST, PUT, DELETE)
 * @param object $conn اتصال قاعدة البيانات
 */
function handleTransactions($method, $conn) {
    switch ($method) {
        case 'GET':
            if (isset($_GET['client_id'])) {
                getTransactions($_GET['client_id'], $conn); // جلب معاملات عميل محدد
            } elseif (isset($_GET['id'])) {
                getTransaction($_GET['id'], $conn); // جلب معاملة محددة بناءً على المعرف
            } else {
                echo json_encode(["message" => "Client ID or Transaction ID is required"]);
            }
            break;
        case 'POST':
            addTransaction($conn); // إضافة معاملة جديدة
            break;
        case 'PUT':
            if (isset($_GET['id'])) {
                updateTransaction($_GET['id'], $conn); // تحديث معاملة محددة
            } else {
                echo json_encode(["message" => "Transaction ID is required for updating"]);
            }
            break;
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteTransaction($_GET['id'], $conn); // حذف معاملة محددة
            } else {
                echo json_encode(["message" => "Transaction ID is required for deleting"]);
            }
            break;
        default:
            echo json_encode(["message" => "Invalid request method for transactions"]);
            break;
    }
}

/**
 * دالة التعامل مع طلبات الإجماليات الخاصة بالعملاء
 *
 * @param string $method طريقة الطلب (GET فقط مدعوم)
 * @param object $conn اتصال قاعدة البيانات
 */
function handleClientsWithTotals($method, $conn) {
    if ($method == 'GET') {
        getClientsWithTotals($conn); // جلب الإجماليات للمدينين والدائنين
    } else {
        echo json_encode(["message" => "Invalid request method for clients_with_totals"]);
    }
}

/**
 * دوال العملاء
 */

/**
 * جلب جميع العملاء من قاعدة البيانات
 *
 * @param object $conn اتصال قاعدة البيانات
 */
function getClients($conn) {
    $sql = "SELECT * FROM clients"; // استعلام SQL لجلب جميع العملاء
    $result = $conn->query($sql);
    $clients = [];

    // تحويل النتائج إلى مصفوفة
    while ($row = $result->fetch_assoc()) {
        $clients[] = $row;
    }

    echo json_encode($clients); // إرجاع البيانات بتنسيق JSON
}

/**
 * جلب عميل محدد بناءً على المعرف
 *
 * @param int|string $id معرف العميل
 * @param object $conn اتصال قاعدة البيانات
 */
function getClient($id, $conn) {
    $id = intval($id); // تحويل المعرف إلى عدد صحيح
    $sql = "SELECT * FROM clients WHERE id = $id"; // استعلام SQL لجلب عميل محدد
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        echo json_encode($row); // إرجاع بيانات العميل بتنسيق JSON
    } else {
        echo json_encode(["message" => "Client not found"]); // رسالة خطأ إذا لم يتم العثور على العميل
    }
}

/**
 * إضافة عميل جديد إلى قاعدة البيانات
 *
 * @param object $conn اتصال قاعدة البيانات
 */
function addClient($conn) {
    // قراءة البيانات المرسلة في جسم الطلب بصيغة JSON
    $data = json_decode(file_get_contents('php://input'), true);

    // التحقق من وجود الحقول المطلوبة
    if (!isset($data['name']) || !isset($data['phone']) || !isset($data['address'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    // حماية البيانات من هجمات SQL Injection باستخدام real_escape_string
    $name = $conn->real_escape_string($data['name']);
    $phone = $conn->real_escape_string($data['phone']);
    $address = $conn->real_escape_string($data['address']);

    // استعلام SQL لإدخال عميل جديد
    $sql = "INSERT INTO clients (name, phone, address) VALUES ('$name', '$phone', '$address')";

    if ($conn->query($sql) === TRUE) {
        // إرجاع رسالة نجاح مع معرف العميل الجديد
        echo json_encode(["message" => "Client added successfully", "id" => $conn->insert_id]);
    } else {
        // إرجاع رسالة خطأ في حال فشل عملية الإدخال
        echo json_encode(["message" => "Error adding client: " . $conn->error]);
    }
}

/**
 * تحديث بيانات عميل محدد في قاعدة البيانات
 *
 * @param int|string $id معرف العميل
 * @param object $conn اتصال قاعدة البيانات
 */
function updateClient($id, $conn) {
    $id = intval($id); // تحويل المعرف إلى عدد صحيح

    // قراءة البيانات المرسلة في جسم الطلب بصيغة JSON
    $data = json_decode(file_get_contents('php://input'), true);

    // التحقق من وجود الحقول المطلوبة
    if (!isset($data['name']) || !isset($data['phone']) || !isset($data['address'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    // حماية البيانات من هجمات SQL Injection باستخدام real_escape_string
    $name = $conn->real_escape_string($data['name']);
    $phone = $conn->real_escape_string($data['phone']);
    $address = $conn->real_escape_string($data['address']);

    // استعلام SQL لتحديث بيانات العميل
    $sql = "UPDATE clients SET name='$name', phone='$phone', address='$address' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        // إرجاع رسالة نجاح عند تحديث البيانات
        echo json_encode(["message" => "Client updated successfully"]);
    } else {
        // إرجاع رسالة خطأ في حال فشل عملية التحديث
        echo json_encode(["message" => "Error updating client: " . $conn->error]);
    }
}

/**
 * حذف عميل محدد من قاعدة البيانات
 *
 * @param int|string $id معرف العميل
 * @param object $conn اتصال قاعدة البيانات
 */
function deleteClient($id, $conn) {
    $id = intval($id); // تحويل المعرف إلى عدد صحيح

    // استعلام SQL لحذف العميل
    $sql = "DELETE FROM clients WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // إرجاع رسالة نجاح عند حذف العميل
        echo json_encode(["message" => "Client deleted successfully"]);
    } else {
        // إرجاع رسالة خطأ في حال فشل عملية الحذف
        echo json_encode(["message" => "Error deleting client: " . $conn->error]);
    }
}

/**
 * دوال المعاملات
 */

/**
 * جلب جميع معاملات عميل محدد من قاعدة البيانات
 *
 * @param int|string $client_id معرف العميل
 * @param object $conn اتصال قاعدة البيانات
 */
function getTransactions($client_id, $conn) {
    $client_id = intval($client_id); // تحويل معرف العميل إلى عدد صحيح
    $sql = "SELECT * FROM transactions WHERE client_id = $client_id ORDER BY date DESC"; // استعلام SQL لجلب معاملات العميل
    $result = $conn->query($sql);
    $transactions = [];

    // تحويل النتائج إلى مصفوفة مع تضمين مسار الصورة إن وجد
    while ($row = $result->fetch_assoc()) {
        $transactions[] = [
            "id" => $row['id'],
            "client_id" => $row['client_id'],
            "amount" => $row['amount'],
            "details" => $row['details'],
            "date" => $row['date'],
            "type" => $row['type'],
            "image_path" => $row['image_path'] // مسار الصورة
        ];
    }

    echo json_encode($transactions); // إرجاع البيانات بتنسيق JSON
}

/**
 * جلب معاملة محددة بناءً على المعرف
 *
 * @param int|string $id معرف المعاملة
 * @param object $conn اتصال قاعدة البيانات
 */
function getTransaction($id, $conn) {
    $id = intval($id); // تحويل المعرف إلى عدد صحيح
    $sql = "SELECT * FROM transactions WHERE id = $id"; // استعلام SQL لجلب معاملة محددة
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        // إرجاع بيانات المعاملة بتنسيق JSON
        echo json_encode([
            "id" => $row['id'],
            "client_id" => $row['client_id'],
            "amount" => $row['amount'],
            "details" => $row['details'],
            "date" => $row['date'],
            "type" => $row['type'],
            "image_path" => $row['image_path']
        ]);
    } else {
        echo json_encode(["message" => "Transaction not found"]); // رسالة خطأ إذا لم يتم العثور على المعاملة
    }
}

/**
 * إضافة معاملة جديدة إلى قاعدة البيانات
 *
 * @param object $conn اتصال قاعدة البيانات
 */
function addTransaction($conn) {
    // قراءة البيانات المرسلة في جسم الطلب بصيغة JSON
    $data = json_decode(file_get_contents('php://input'), true);

    // التحقق من وجود الحقول المطلوبة
    if (!isset($data['client_id']) || !isset($data['amount']) || !isset($data['details']) || !isset($data['date']) || !isset($data['type'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    // تحويل القيم إلى الأنواع الصحيحة وحماية البيانات
    $client_id = intval($data['client_id']);
    $amount = floatval($data['amount']);
    $details = $conn->real_escape_string($data['details']);
    $date = $conn->real_escape_string($data['date']);
    $type = $conn->real_escape_string($data['type']);

    // التعامل مع الصورة المشفرة بـ Base64 إذا كانت موجودة
    $image_path = NULL;
    if (isset($data['image_base64']) && !empty($data['image_base64'])) {
        $image_data = $data['image_base64'];
        // استخراج نوع الصورة وبياناتها باستخدام تعبير منتظم
        if (preg_match('/data:image\/(\w+);base64,/', $image_data, $type_match)) {
            $image_data = substr($image_data, strpos($image_data, ',') + 1);
            $image_type = strtolower($type_match[1]); // jpg, png, gif

            // التحقق من تنسيق الصورة
            if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo json_encode(["message" => "Invalid image format"]);
                return;
            }

            // فك ترميز بيانات الصورة من Base64
            $image_data = base64_decode($image_data);
            if ($image_data === false) {
                echo json_encode(["message" => "Base64 decode failed"]);
                return;
            }
        } else {
            echo json_encode(["message" => "Invalid image data"]);
            return;
        }

        // إنشاء مجلد uploads إذا لم يكن موجودًا
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        // إنشاء اسم ملف فريد للصورة
        $file_name = uniqid() . "." . $image_type;
        $file_path = $target_dir . $file_name;

        // حفظ الصورة على الخادم
        if (file_put_contents($file_path, $image_data)) {
            $image_path = $file_path;
        } else {
            echo json_encode(["message" => "Error saving image"]);
            return;
        }
    }

    // استعلام SQL لإدخال المعاملة الجديدة
    $sql = "INSERT INTO transactions (client_id, amount, details, date, type, image_path) VALUES ($client_id, $amount, '$details', '$date', '$type', '$image_path')";

    if ($conn->query($sql) === TRUE) {
        // تحديث رصيد العميل بناءً على نوع المعاملة
        if ($type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance + $amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance - $amount WHERE id = $client_id";
        }
        $conn->query($balance_update); // تنفيذ استعلام تحديث الرصيد

        // إرجاع رسالة نجاح مع معرف المعاملة الجديدة
        echo json_encode(["message" => "Transaction added successfully", "id" => $conn->insert_id]);
    } else {
        // إرجاع رسالة خطأ في حال فشل عملية الإدخال
        echo json_encode(["message" => "Error adding transaction: " . $conn->error]);
    }
}

/**
 * تحديث معاملة موجودة في قاعدة البيانات
 *
 * @param int|string $id معرف المعاملة
 * @param object $conn اتصال قاعدة البيانات
 */
function updateTransaction($id, $conn) {
    // قراءة البيانات المرسلة في جسم الطلب بصيغة JSON
    $data = json_decode(file_get_contents('php://input'), true);

    // التحقق من وجود الحقول المطلوبة
    if (!isset($data['amount']) || !isset($data['details']) || !isset($data['date']) || !isset($data['type'])) {
        echo json_encode(["message" => "Missing required fields"]);
        return;
    }

    // تحويل القيم إلى الأنواع الصحيحة وحماية البيانات
    $id = intval($id);
    $new_amount = floatval($data['amount']);
    $details = $conn->real_escape_string($data['details']);
    $date = $conn->real_escape_string($data['date']);
    $new_type = $conn->real_escape_string($data['type']);

    // الحصول على المعاملة الحالية لمعرفة نوعها القديم ومبلغها
    $sql = "SELECT * FROM transactions WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        $old_type = $row['type'];
        $old_amount = floatval($row['amount']);
        $client_id = $row['client_id'];

        // إلغاء تأثير المعاملة القديمة على رصيد العميل
        if ($old_type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance - $old_amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance + $old_amount WHERE id = $client_id";
        }
        $conn->query($balance_update); // تنفيذ استعلام تحديث الرصيد

        // التعامل مع الصورة المشفرة بـ Base64 إذا كانت موجودة
        $image_path = $row['image_path']; // الحفاظ على الصورة القديمة إذا لم يتم تحديثها
        if (isset($data['image_base64']) && !empty($data['image_base64'])) {
            $image_data = $data['image_base64'];
            // استخراج نوع الصورة وبياناتها باستخدام تعبير منتظم
            if (preg_match('/data:image\/(\w+);base64,/', $image_data, $type_match)) {
                $image_data = substr($image_data, strpos($image_data, ',') + 1);
                $image_type = strtolower($type_match[1]); // jpg, png, gif

                // التحقق من تنسيق الصورة
                if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                    echo json_encode(["message" => "Invalid image format"]);
                    return;
                }

                // فك ترميز بيانات الصورة من Base64
                $image_data = base64_decode($image_data);
                if ($image_data === false) {
                    echo json_encode(["message" => "Base64 decode failed"]);
                    return;
                }
            } else {
                echo json_encode(["message" => "Invalid image data"]);
                return;
            }

            // إنشاء مجلد uploads إذا لم يكن موجودًا
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true);
            }

            // إنشاء اسم ملف فريد للصورة
            $file_name = uniqid() . "." . $image_type;
            $file_path = $target_dir . $file_name;

            // حفظ الصورة على الخادم
            if (file_put_contents($file_path, $image_data)) {
                $image_path = $file_path;

                // حذف الصورة القديمة إذا كانت موجودة
                if ($row['image_path'] && file_exists($row['image_path'])) {
                    unlink($row['image_path']);
                }
            } else {
                echo json_encode(["message" => "Error saving image"]);
                return;
            }
        }

        // استعلام SQL لتحديث المعاملة
        $sql_update = "UPDATE transactions SET amount = $new_amount, details = '$details', date = '$date', type = '$new_type', image_path = '$image_path' WHERE id = $id";

        if ($conn->query($sql_update) === TRUE) {
            // تطبيق تأثير المعاملة الجديدة على رصيد العميل
            if ($new_type == 'مدين') {
                $balance_update_new = "UPDATE clients SET balance = balance + $new_amount WHERE id = $client_id";
            } else {
                $balance_update_new = "UPDATE clients SET balance = balance - $new_amount WHERE id = $client_id";
            }
            $conn->query($balance_update_new); // تنفيذ استعلام تحديث الرصيد

            // إرجاع رسالة نجاح عند تحديث المعاملة
            echo json_encode(["message" => "Transaction updated successfully"]);
        } else {
            // إرجاع رسالة خطأ في حال فشل عملية التحديث
            echo json_encode(["message" => "Error updating transaction: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Transaction not found"]); // رسالة خطأ إذا لم يتم العثور على المعاملة
        return;
    }
}

/**
 * حذف معاملة محددة من قاعدة البيانات
 *
 * @param int|string $id معرف المعاملة
 * @param object $conn اتصال قاعدة البيانات
 */
function deleteTransaction($id, $conn) {
    $id = intval($id); // تحويل المعرف إلى عدد صحيح

    // الحصول على المعاملة الحالية لمعرفة نوعها ومبلغها
    $sql = "SELECT * FROM transactions WHERE id = $id";
    $result = $conn->query($sql);

    if ($row = $result->fetch_assoc()) {
        $type = $row['type'];
        $amount = floatval($row['amount']);
        $client_id = $row['client_id'];

        // تحديث رصيد العميل بناءً على نوع المعاملة
        if ($type == 'مدين') {
            $balance_update = "UPDATE clients SET balance = balance - $amount WHERE id = $client_id";
        } else {
            $balance_update = "UPDATE clients SET balance = balance + $amount WHERE id = $client_id";
        }
        $conn->query($balance_update); // تنفيذ استعلام تحديث الرصيد

        // حذف الصورة إذا كانت موجودة
        if ($row['image_path'] && file_exists($row['image_path'])) {
            unlink($row['image_path']);
        }

        // استعلام SQL لحذف المعاملة
        $sql = "DELETE FROM transactions WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            // إرجاع رسالة نجاح عند حذف المعاملة
            echo json_encode(["message" => "Transaction deleted successfully"]);
        } else {
            // إرجاع رسالة خطأ في حال فشل عملية الحذف
            echo json_encode(["message" => "Error deleting transaction: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Transaction not found"]); // رسالة خطأ إذا لم يتم العثور على المعاملة
    }
}

/**
 * دوال الإجماليات
 */

/**
 * جلب الإجماليات للمدينين والدائنين
 *
 * @param object $conn اتصال قاعدة البيانات
 */
function getClientsWithTotals($conn) {
    // استعلام SQL لحساب إجمالي المبالغ المدينة
    $sql_given = "SELECT SUM(amount) as total_given FROM transactions WHERE type = 'مدين'";
    // استعلام SQL لحساب إجمالي المبالغ الدائنة
    $sql_taken = "SELECT SUM(amount) as total_taken FROM transactions WHERE type = 'دائن'";

    $result_given = $conn->query($sql_given);
    $result_taken = $conn->query($sql_taken);

    $total_given = 0;
    $total_taken = 0;

    // الحصول على إجمالي المبالغ المدينة
    if ($row = $result_given->fetch_assoc()) {
        $total_given = floatval($row['total_given']);
    }

    // الحصول على إجمالي المبالغ الدائنة
    if ($row = $result_taken->fetch_assoc()) {
        $total_taken = floatval($row['total_taken']);
    }

    // إرجاع الإجماليات بتنسيق JSON
    echo json_encode([
        "total_given" => $total_given,
        "total_taken" => $total_taken
    ]);
}
?>
